import logo from './logo.svg';
import './App.css';

import NewLogin from './Components/NewLogin';
function App() {
  return (
    <div className="App">
   
      <NewLogin></NewLogin>
    </div>
  );
}

export default App;
